﻿namespace WildRoadApp_Api.API.DataContracts.Responses
{
    public class UserCreationResponse
    {
    }
}
