﻿using AutoMapper;

namespace WildRoadApp_Api.IoC.Configuration.AutoMapper.Profiles
{
    public class ServicesMappingProfile : Profile
    {
        public ServicesMappingProfile()
        {
            //TODO: complete with business and repository mappings
        }
    }
}
