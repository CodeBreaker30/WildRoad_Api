﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildRoadApp_Api.Services.NationalParkLogic
{
    class NationalParkLogic
    {
    }
}
